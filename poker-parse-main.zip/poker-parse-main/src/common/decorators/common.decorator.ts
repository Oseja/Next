export interface CommonDecorator {}
