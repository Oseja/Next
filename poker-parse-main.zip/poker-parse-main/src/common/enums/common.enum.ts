export interface CommonEnum {}
