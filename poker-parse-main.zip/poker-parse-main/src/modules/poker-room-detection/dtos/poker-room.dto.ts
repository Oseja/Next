export class PokerRoomDto {}
