import { Controller } from '@nestjs/common';

@Controller('poker-room')
export class PokerRoomController {}
