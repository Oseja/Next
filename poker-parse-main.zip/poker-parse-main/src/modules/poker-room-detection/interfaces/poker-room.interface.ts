export interface PokerRoom {}

export interface PokerSite {
  name: string;
  regex: RegExp;
}
