export class DataStreamObserver {}
