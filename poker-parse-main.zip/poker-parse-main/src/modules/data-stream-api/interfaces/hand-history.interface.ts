export interface HandHistoryInterface {}
