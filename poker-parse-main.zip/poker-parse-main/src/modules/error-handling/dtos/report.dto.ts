export class ReportDto {}
