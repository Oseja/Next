export class ParsedHandHistoryDto {}
