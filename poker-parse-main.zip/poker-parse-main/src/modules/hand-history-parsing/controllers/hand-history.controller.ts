import { Controller } from '@nestjs/common';

@Controller('hand-history')
export class HandHistoryController {}
